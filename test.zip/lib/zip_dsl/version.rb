class ZipDSL
  VERSION = "1.3.1"
end
