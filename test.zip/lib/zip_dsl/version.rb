class ZipDSL
  VERSION = "1.3.0"
end
