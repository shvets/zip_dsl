module ZipDSL
  VERSION = "1.0.8"
end
